# Installazione e importazione dei moduli per Microsoft Graph
Install-Module Microsoft.Graph -Scope CurrentUser -Force
Import-Module Microsoft.Graph.Authentication
Import-Module Microsoft.Graph.Applications      

# Installazione e importazione dei moduli per PnP PowerShell
Install-Module PnP.PowerShell -Scope CurrentUser -Force
Import-Module PnP.PowerShell

# Installazione e importazione dei moduli per SharePoint Online PowerShell
Install-Module Microsoft.Online.SharePoint.PowerShell -Scope CurrentUser -Force 
Import-Module Microsoft.Online.SharePoint.PowerShell

# Verificare i moduli installati e importati correttamente
Get-Module -ListAvailable Microsoft.Graph*, PnP.PowerShell, Microsoft.Online.SharePoint.PowerShell