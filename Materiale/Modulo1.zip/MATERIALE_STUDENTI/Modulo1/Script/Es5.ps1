#Creazione Certificati Azure
New-PnPAzureCertificate -OutPfx "C:\Cert\cert.pfx" -OutCert "C:\Cert\cert.cer"

#Verificare il Thumbprint
Get-ChildItem Cert:\LocalMachine\My

#Importare i moduli necessari per Microsoft Graph SOLO SE NON GIÀ CARICATI
Import-Module Microsoft.Graph.Authentication
Import-Module Microsoft.Graph.Users

#Connettersi a Graph compilando il comando
Connect-MgGraph -ClientId "<APP_ID_dell'Enterprise_Application>" `
-TenantId "<TENANT_ID>" `
-CertificateThumbprint "<THUMBPRINT_annotato_al_Passo_4>"

#Verificare il contesto corrente di Microsoft Graph
Get-MgContext

#Listare tutti gli utenti del tenant
Get-MgUser -All | Select-Object DisplayName, UserPrincipalName, Id

#Creare un nuovo utente con password temporanea
$PasswordProfile = @{
      Password = "P@ssw0rd-Temp!2026"
      ForceChangePasswordNextSignIn = $true
    }
    
    New-MgUser -DisplayName "User Test Graph" `
      -PasswordProfile $PasswordProfile `
      -AccountEnabled `
      -MailNickname "UserTestGraph" `
      -UserPrincipalName "usertestgraph@XXXXXX"

# Elencare i gruppi del tenant
Get-MgGroup -All | Select-Object DisplayName, Id
    
# Oppure, verificare le licenze assegnate a un utente specifico
Get-MgUserLicenseDetail -UserId "User"