#Installazione modulo Microsoft.Online.SharePoint.PowerShell
Install-Module -Name Microsoft.Online.SharePoint.PowerShell

#Update modulo Microsoft.Online.SharePoint.PowerShell
Update-Module -Name Microsoft.Online.SharePoint.PowerShell

#Connessione al servizio SharePoint Online
Connect-SPOService -Url https://TENANT-admin.sharepoint.com -Credential admin@TENANT.onmicrosoft.com

#Modifica dei permessi del gruppo "Marketing Department Members" nel sito "MarketingDepartment"
Set-SPOSiteGroup `
-Site "https://TENANT.sharepoint.com/sites/MarketingDepartment" `
-Identity "Marketing Department Members" `
-PermissionLevelsToRemove "Edit" `
-PermissionLevelsToAdd "Contribute"

#Visualizzazione dei permessi aggiornati del gruppo "Marketing Department Members" nel sito "MarketingDepartment"
Get-SPOSiteGroup `
-Site "https://TENANT.sharepoint.com/sites/MarketingDepartment" `
-Group "Marketing Department Members" | Select Title, Roles

