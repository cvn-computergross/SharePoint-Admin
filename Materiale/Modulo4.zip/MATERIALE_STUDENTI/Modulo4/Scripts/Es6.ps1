#Installare i moduli PnP.PowerShell e Microsoft.Graph se non già presenti, con i comandi seguenti (da eseguire in PowerShell come Amministratore):
Install-Module PnP.PowerShell -Scope CurrentUser -Force
Install-Module Microsoft.Graph -Scope CurrentUser -Force


# Salvare le seguenti variabili con i valori corretti per il proprio tenant e la propria app registration (Enterprise Application) creata al Modulo 1
$AppId          = "<APP_ID_dell'Enterprise_Application>"        
# da Modulo 1 - Esercizio 5
$TenantId       = "<TENANT_ID>"
$Thumbprint     = "<THUMBPRINT_del_certificato>"                
# annotato al Modulo 1 - Esercizio 5, Passo 4
$AdminSiteUrl   = "https://tenant_name-admin.sharepoint.com"     
# dove tenant_name è il nome del proprio tenant

#Eseguire la connessione a Microsoft Graph 
Connect-MgGraph -ClientId $AppId -TenantId $TenantId -CertificateThumbprint $Thumbprint
Get-MgContext   # verificare che AuthType risulti "AppOnly"

#Eseguire la connessione a PnP PowerShell
Connect-PnPOnline -Url $AdminSiteUrl -ClientId $AppId -Tenant $TenantId -Thumbprint $Thumbprint

#Eseguire la connessione a SharePoint Online PowerShell
Connect-SPOService -Url $AdminSiteUrl -ClientId $AppId -TenantId $TenantId -CertificatePath "C:\Cert\cert.pfx" 

