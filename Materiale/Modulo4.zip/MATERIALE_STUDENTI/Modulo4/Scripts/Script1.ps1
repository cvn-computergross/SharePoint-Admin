# Report OneDrive: storage in MB, cestini in KB
# Requisiti: Microsoft.Online.SharePoint.PowerShell + PnP.PowerShell
# Connessione app-only gia' eseguita. Riusa $AppId, $TenantId, $Thumbprint.

$OutputCsv = "C:\Temp\Report_Cestini_OneDrive.csv"

$oneDriveSites = Get-SPOSite -IncludePersonalSite $true -Limit All -Filter "Url -like '-my.sharepoint.com/personal/'"

$report = foreach ($site in $oneDriveSites) {

    $s = Get-SPOSite -Identity $site.Url

    Connect-PnPOnline -Url $s.Url -ClientId $AppId -Tenant $TenantId -Thumbprint $Thumbprint

    $l1 = Get-PnPRecycleBinItem -FirstStage -RowLimit 500000 -ErrorAction SilentlyContinue
    $l2 = Get-PnPRecycleBinItem -SecondStage -RowLimit 500000 -ErrorAction SilentlyContinue

    # Size in BYTE: cast a [long] prima di sommare
    $l1Bytes = ($l1 | ForEach-Object { [long]$_.Size } | Measure-Object -Sum).Sum
    $l2Bytes = ($l2 | ForEach-Object { [long]$_.Size } | Measure-Object -Sum).Sum
    if (-not $l1Bytes) { $l1Bytes = 0 }
    if (-not $l2Bytes) { $l2Bytes = 0 }

    [PSCustomObject]@{
        OneDriveUrl        = $s.Url
        StorageTotaleMB    = "{0:N2}" -f $s.StorageQuota
        StorageUsatoMB     = "{0:N2}" -f $s.StorageUsageCurrent
        CestinoLivello1KB  = "{0:N2}" -f ($l1Bytes / 1KB)
        CestinoLivello2KB  = "{0:N2}" -f ($l2Bytes / 1KB)
    }
}

$report | Format-Table -AutoSize
$report | Export-Csv -Path $OutputCsv -NoTypeInformation -Encoding UTF8