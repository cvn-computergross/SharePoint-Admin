# Richiede il modulo: PnP.PowerShell
# Login con app registration Full Control (Sites.FullControl.All)
# Riutilizza $AppId, $TenantId, $Thumbprint

$TenantAdminUrl = "https://tenant_name-admin.sharepoint.com"
$OutputCsv      = "C:\Temp\Report_Permessi_Tenant.csv"

$permessi = @()

function Get-PermessiWeb($web) {
    Get-PnPProperty -ClientObject $web -Property HasUniqueRoleAssignments, RoleAssignments, Url, Title | Out-Null
    $permessiUnivoci = $web.HasUniqueRoleAssignments

    foreach ($assegnazione in $web.RoleAssignments) {
        Get-PnPProperty -ClientObject $assegnazione -Property RoleDefinitionBindings, Member | Out-Null

        $livelli = $assegnazione.RoleDefinitionBindings | Where-Object { $_.Name -ne "Limited Access" } | Select-Object -ExpandProperty Name
        if (-not $livelli -or $livelli.Count -eq 0) { continue }

        $tipoPrincipal = $assegnazione.Member.PrincipalType

        if ($tipoPrincipal -eq "SharePointGroup") {
            try {
                $membriGruppo = Get-PnPGroupMember -Identity $assegnazione.Member.LoginName -ErrorAction Stop
            } catch { $membriGruppo = @() }

            foreach ($utente in $membriGruppo) {
                $script:permessi += [PSCustomObject]@{ SitoUrl = $web.Url; SitoTitolo = $web.Title; Utente = $utente.Title; TipoPrincipal = $tipoPrincipal; LivelloPermesso = ($livelli -join ","); Gruppo = $assegnazione.Member.Title; PermessiUnivoci = $permessiUnivoci }
            }
        } else {
            $script:permessi += [PSCustomObject]@{ SitoUrl = $web.Url; SitoTitolo = $web.Title; Utente = $assegnazione.Member.Title; TipoPrincipal = $tipoPrincipal; LivelloPermesso = ($livelli -join ","); Gruppo = "Permesso diretto"; PermessiUnivoci = $permessiUnivoci }
        }
    }
}

# 1) Connessione admin ed enumerazione di TUTTI i siti
Connect-PnPOnline -Url $TenantAdminUrl -ClientId $AppId -Tenant $TenantId -Thumbprint $Thumbprint
$siti = Get-PnPTenantSite | Where-Object { $_.Template -notin @("SRCHCEN#0","SPSMSITEHOST#0") }
Write-Host "Trovati $($siti.Count) siti da analizzare." -ForegroundColor Cyan

# 2) Ciclo su ogni sito + sottositi
foreach ($sito in $siti) {
    Write-Host "Analizzo: $($sito.Url)" -ForegroundColor Yellow
    try {
        Connect-PnPOnline -Url $sito.Url -ClientId $AppId -Tenant $TenantId -Thumbprint $Thumbprint -ErrorAction Stop

        $webPrincipale = Get-PnPWeb -Includes RoleAssignments
        Get-PermessiWeb $webPrincipale

        $sottositi = Get-PnPSubWeb -Recurse -ErrorAction SilentlyContinue
        foreach ($sottosito in $sottositi) {
            Connect-PnPOnline -Url $sottosito.Url -ClientId $AppId -Tenant $TenantId -Thumbprint $Thumbprint
            Get-PermessiWeb $sottosito
        }
    }
    catch {
        Write-Warning "Impossibile analizzare $($sito.Url): $($_.Exception.Message)"
    }
}

# 3) Export finale
$permessi | Export-Csv -Path $OutputCsv -NoTypeInformation -Encoding UTF8