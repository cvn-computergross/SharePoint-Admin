# Richiede il modulo: PnP.PowerShell
# Login con app registration Full Control + Graph (GroupMember.Read.All / Directory.Read.All)
# Riutilizza $AppId, $TenantId, $Thumbprint, $AdminSiteUrl

Connect-PnPOnline -Url $AdminSiteUrl -ClientId $AppId -Tenant $TenantId -Thumbprint $Thumbprint

$guestReport = @()

# FONTE 1 - Guest membri dei gruppi Microsoft 365 (siti Teams-connected)
$gruppi = Get-PnPMicrosoft365Group
Write-Host "Gruppi M365 da analizzare: $($gruppi.Count)" -ForegroundColor Cyan

foreach ($g in $gruppi) {
    $membri = Get-PnPMicrosoft365GroupMember -Identity $g.Id -ErrorAction SilentlyContinue
    foreach ($m in $membri) {
        if ($m.UserType -eq "Guest" -or $m.UserPrincipalName -like "*#EXT#*") {
            $guestReport += [PSCustomObject]@{
                SitoUrl    = $g.SiteUrl
                SitoTitolo = $g.DisplayName
                NomeGuest  = $m.DisplayName
                EmailGuest = $m.Email
                Origine    = "Gruppo M365"
                LoginName  = $m.UserPrincipalName
            }
        }
    }
}

# FONTE 2 - Guest con permessi diretti / gruppi SP su OGNI sito del tenant
# (copre communication site, siti classici, permessi rotti, ecc.)

$siti = Get-PnPTenantSite | Where-Object { $_.Template -notlike "SPSPERS*" }
Write-Host "Siti da analizzare: $($siti.Count)" -ForegroundColor Cyan

foreach ($sito in $siti) {
    Write-Host "Analizzo: $($sito.Url)" -ForegroundColor Yellow
    try {
        Connect-PnPOnline -Url $sito.Url -ClientId $AppId -Tenant $TenantId -Thumbprint $Thumbprint -ErrorAction Stop

        $guestSito = Get-PnPUser | Where-Object { $_.LoginName -like "*#ext#*" -or $_.LoginName -like "*urn:spo:guest*" }
        foreach ($u in $guestSito) {
            $guestReport += [PSCustomObject]@{
                SitoUrl    = $sito.Url
                SitoTitolo = $sito.Title
                NomeGuest  = $u.Title
                EmailGuest = $u.Email
                Origine    = "Permesso sito"
                LoginName  = $u.LoginName
            }
        }
    }
    catch {
        Write-Warning "Errore su $($sito.Url): $($_.Exception.Message)"
    }
}

# Export finale (deduplica per sito + guest)
$guestReport |
    Sort-Object SitoUrl, EmailGuest -Unique |
    Export-Csv -Path "C:\Temp\Report_Guest_Sites.csv" -NoTypeInformation -Encoding UTF8

Write-Host "Trovati $($guestReport.Count) guest totali." -ForegroundColor Green