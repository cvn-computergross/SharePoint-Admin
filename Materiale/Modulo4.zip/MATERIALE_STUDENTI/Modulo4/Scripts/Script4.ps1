# Richiede il modulo: PnP.PowerShell
# Riutilizza $AppId, $TenantId, $Thumbprint impostate al Passo 1
$SiteUrl = "https://tenant_name.sharepoint.com/sites/MarketingDepartment"

Connect-PnPOnline -Url $SiteUrl -ClientId $AppId -Tenant $TenantId -Thumbprint $Thumbprint

# Seleziona solo le librerie documentali reali (esclude liste di sistema)
$librerie = Get-PnPList -Includes IsSystemList, RootFolder | Where-Object {
    ($_.BaseType -eq "DocumentLibrary" -and $_.IsSystemList -eq $false)
}

$librerie | ForEach-Object {
    Get-PnPListItem -List $_.RootFolder.Name | Where-Object { $_.FieldValues.FSObjType -ne 1 } |
    Select-Object `
        @{n = "Libreria";      e = { $_.ParentList.Title } },
        @{n = "File";          e = { $_.FieldValues.FileRef } },
        @{n = "CreatoDa";      e = { ($_.FieldValues.Created_x0020_By).Split("|")[2] } },
        @{n = "DataCreazione"; e = { $_.FieldValues.Created } },
        @{n = "ModificatoDa";  e = { ($_.FieldValues.Modified_x0020_By).Split("|")[2] } },
        @{n = "DataModifica";  e = { $_.FieldValues.Modified } }
} | Export-Csv -Path "C:\Temp\Report_File_Librerie.csv" -NoTypeInformation -Append -Encoding UTF8

Import-Csv "C:\Temp\Report_File_Librerie.csv" | Format-Table -AutoSize